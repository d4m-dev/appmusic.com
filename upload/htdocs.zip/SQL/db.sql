-- Tạo bảng users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    email VARCHAR(100),
    role ENUM('user','admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng song
CREATE TABLE songs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  artist VARCHAR(255) NOT NULL,
  genre VARCHAR(100),
  lyrics TEXT,
  file_path VARCHAR(255) NOT NULL,
  cover_path VARCHAR(255),
  views INT DEFAULT 0,
  uploaded_time DATETIME DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Thêm dữ liệu vào bảng songs
INSERT INTO songs (title, artist, genre, lyrics, file_path, cover_path, views) VALUES
('Hay Là Chúng Ta Cứ Như Vậy Một Vạn Năm', 'Hoàng Tiêu Vân | Trường Nguyệt Tẫn Minh OST', 'OST', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/cunhuvaymotvannam/2.mp3', 'https://i.postimg.cc/sfB4vtbq/1.jpg', 1),

('Em Đồng Ý | I Do', 'ĐỨC PHÚC x 911 x KHẮC HƯNG OFFICIAL', 'Official', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/weddingsongs/ido.mp3', 'https://i.postimg.cc/TYDMgYZM/1.jpg', 2),

('Vở Kịch Của Em x Vây Giữ REMIX', 'Hồ Phong An x HuyN FT', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/vokichcuaem/2.mp3', 'https://i.postimg.cc/SQCRjdNk/1.jpg', 1),

('Yêu Em Nhưng Không Với Tới x Vây Giữ REMIX', 'DC Tâm x SS x AM Remix', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/yeuemnhungkhongvoitoi/2.mp3', 'https://i.postimg.cc/8PTpcV0m/1.jpg', 3),

('Anh Đau Từ Lúc Em Đi REMIX', 'Trần Mạnh Cường', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/anhdautulucemdi/2.mp3', 'https://i.postimg.cc/5t3nSLmr/1.jpg', 2),

('Mạnh Bà lofi', 'Linh Hương Luz', 'Lofi', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/manhba/2.mp3', 'https://i.postimg.cc/B62DC0sn/1.jpg', 1),

('Địa Đàng REMIX', 'Hoàng Oanh x ACV', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/diadang/2.mp3', 'https://i.postimg.cc/GhwgrL9q/1.jpg', 3),

('Tái Sinh REMIX', 'Tùng Dương x ACV', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/taisinh/2.mp3', 'https://i.postimg.cc/mk0vWCJw/1.jpg', 2),

('Ải Hồng Nhan REMIX', 'Cần Vinh x Lee Ken', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/aihongnhan/2.mp3', 'https://i.postimg.cc/7hLc2m8X/1.jpg', 1),

('Thương Thì Thôi REMIX', 'Jank', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/thuongthithoi/2.mp3', 'https://i.postimg.cc/v8Wk4gJp/1.jpg', 3),

('Ba Kiếp Tình Một Kiếp Duyên lofi', 'Lâm Tuấn x MewMew lofi', 'Official', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/bakieptinhmotkiepduyen/2.mp3', 'https://i.postimg.cc/K85HJ6GQ/1.jpg', 1),

('Trả Lại Thanh Xuân Cho Em REMIX', 'Mochiii x Domino Remix', 'Remix', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/tralaithanhxuanchoem/2.mp3', 'https://i.postimg.cc/4d3yYRd0/1.jpg', 2),

('Đào Hoa Nặc', '旺仔小乔', 'Nhạc Trung', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/daohoanac/2.mp3', 'https://i.postimg.cc/htC0JcPF/1.jpg', 3),

('Vây Giữ', 'Vương Tĩnh Văn', 'Nhạc Trung', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/vaygiu/2.mp3', 'https://i.postimg.cc/wx1byWs1/1.jpg', 1),

('Khóa Ly Biệt Live', 'Anh Tú', 'Hát Live', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/khoalybiet/2.mp3', 'https://i.postimg.cc/3NMRVV3b/1.jpg', 2),

('Anh Thôi Nhân Nhượng Cover', 'Linh Hương Luz', 'Cover', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/anhthoinhannhuong/2.mp3', 'https://i.postimg.cc/05cDXG3G/1.jpg', 3),

('Nơi Đâu Tìm Thấy Em lofi', 'Chu Bin', 'Lofi', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/noidautimthayem/2.mp3', 'https://i.postimg.cc/tJzQQ37W/1.jpg', 1),

('E Là Không Thể', 'Anh Quân x Đông Thiên Đức', 'Official', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/elakhongthe/2.mp3', 'https://i.postimg.cc/tJ8PbxfR/1.jpg', 2),

('Mashup 6 in 1', 'Mochiii Cover', 'Mashup', '', 'https://upnhanh.us/files/f8c826d4d62d9e166e12ac4877bafc93/c9097511455de58ce9dba0203ac0f5f5/mashup6in1mochiii.mp3', 'https://i.postimg.cc/MZ7GFBLq/1.jpg', 3),

('Cạn Tình Như Thế', 'Dickson x Thành Đạt', 'Official', '', 'https://github.com/d4m-dev/media/raw/refs/heads/main/cantinhnhuthe/2.mp3', 'https://i.postimg.cc/MHZ67gf9/1.jpg', 1);

-- Tạo bảng thể loại
CREATE TABLE genres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Thêm dữ liệu vào bảng thể loại
INSERT INTO genres (name, description) VALUES
('OST', 'Nhạc phim, nhạc chủ đề từ điện ảnh hoặc truyền hình'),
('Remix', 'Các bản phối lại sôi động, thường có beat mạnh'),
('Lofi', 'Giai điệu nhẹ nhàng, thư giãn, thường dùng để học tập'),
('Official', 'Bản phát hành chính thức từ nghệ sĩ hoặc hãng đĩa'),
('Cover', 'Bài hát được hát lại bởi nghệ sĩ khác'),
('Nhạc Trung', 'Nhạc Hoa ngữ hoặc có nguồn gốc từ Trung Quốc'),
('Hát Live', 'Ghi âm từ sân khấu biểu diễn trực tiếp'),
('Mashup', 'Pha trộn nhiều bài hát lại thành một bản phối'),
('Ballad', 'Giai điệu chậm, cảm xúc, thường nói về tình yêu');

-- 1. Bảng playlist chính
CREATE TABLE playlists (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  createdat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 2. Bảng gán bài hát vào playlist (trung gian)
CREATE TABLE playlist_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  playlist_id INT NOT NULL,
  song_id INT NOT NULL,
  added_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (playlist_id) REFERENCES playlists(id),
  FOREIGN KEY (song_id) REFERENCES songs(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng playlist_songs
CREATE TABLE playlist_songs (
    playlist_id INT,
    song_id INT,
    PRIMARY KEY (playlist_id, song_id),
    FOREIGN KEY (playlist_id) REFERENCES playlists(id),
    FOREIGN KEY (song_id) REFERENCES songs(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng favorites
CREATE TABLE favorites (
    user_id INT,
    song_id INT,
    PRIMARY KEY (user_id, song_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (song_id) REFERENCES songs(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng comments
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    song_id INT,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (song_id) REFERENCES songs(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Tạo bảng ratings
CREATE TABLE ratings (
    user_id INT,
    song_id INT,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    PRIMARY KEY (user_id, song_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (song_id) REFERENCES songs(id)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

